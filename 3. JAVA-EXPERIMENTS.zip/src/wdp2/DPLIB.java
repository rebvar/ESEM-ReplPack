/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wdp2;

import GIS.CHRM_GIS;

import java.io.File;
import weka.core.*;

import java.io.FileReader;
import java.io.FileWriter;


import java.util.*;
import weka.attributeSelection.AttributeSelection;


import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.NominalPrediction;
import weka.clusterers.*;
import weka.core.neighboursearch.LinearNNSearch;


import weka.attributeSelection.*;
import weka.classifiers.Classifier;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LinearRegression;

/**
 *
 * @author sehossei
 */
public class DPLIB {

    public static int[] features;
    public static int[] featuresa;
    public static String dp;
    public static double cf = 0.5;
    public static boolean convertToBinary = true;
    
    
    public static int madBugCount = 0;
    
    public static Random rnd = new Random(System.currentTimeMillis());
    
    
    public static int find(int[] arr, int val) {

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                return i;
            }
        }
        return -1;
    }

    public static boolean findB(int[] arr, int val) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                return true;
            }
        }
        return false;
    }

    public static String[] getFiles(String path) {
        File dir = new File(path);
        ArrayList<String> ret = new ArrayList<String>();
        File[] filesList = dir.listFiles();
        for (File f : filesList) {
            if (f.isDirectory()) {
                continue;
            }
            if (f.isFile()) {
                if (f.getName().indexOf(".arff") > 0) {
                    ret.add(f.getName());
                } else {
                    continue;
                }
            }
        }
        return ret.toArray(new String[1]);
    }

    public static String[] getFiles(String path, String ext) {
        File dir = new File(path);
        ArrayList<String> ret = new ArrayList<String>();
        File[] filesList = dir.listFiles();
        for (File f : filesList) {
            if (f.isDirectory()) {
                continue;
            }
            if (f.isFile()) {
                if (f.getName().endsWith(ext)) {
                    ret.add(f.getName());
                }
            }
        }
        return ret.toArray(new String[1]);
    }
    
    public static Instances LoadCSV(String file, String dp, int ft[]) throws Exception {

        ArrayList<String> files = new ArrayList<String>();
        files.add(file);
        return DPLIB.LoadCSV(files, dp, ft);

    }

    public static Instances LoadCSV(ArrayList<String> files, String dp, int ft[]) throws Exception {
        int id = 0;
        try {
            Arrays.sort(ft);

            String f = files.get(0);
            FileReader file = new FileReader(dp + f);
            Instances insts = new Instances(file);
            int numAttrs = insts.numAttributes();
            insts.delete();
            int skipPercent = 0, loadPercent = 100;
            for (String f2 : files) {
                String f1 = f2.trim();
                file = new FileReader(dp + f1);
                Instances data = new Instances(file);

                int num = data.numInstances();
                for (int i = (int) (num * skipPercent / 100.0); i < (int) (num * loadPercent / 100.0); i++) {
                    data.instance(i).SetID(f1.substring(0, f1.length() - 5) + "@" + String.valueOf(i));// + ";DatasetName=" + String.join(",", files) + "@";
                    //data.instance(i).extra = "I=" + String.valueOf((int) data.instance(i).classValue());
                    data.instance(i).SetInstIndex(id);
                    insts.add(data.instance(i));
                    id++;
                    
                }

            }

            for (int i = 0; i < numAttrs - 1; i++) {
                int attrInd = numAttrs - 1 - 1 - i;

                if (!findB(ft, attrInd)) {
                    insts.deleteAttributeAt(attrInd);
                }
            }
            numAttrs = ft.length;

            int num = insts.numInstances();
            for (int i = 0; i < num; i++) {

                double[] lst = insts.instance(i).toDoubleArray();
            }

            num = insts.numInstances();

            if (DPLIB.convertToBinary) {

                for (int i = 0; i < num; i++) {
                    if (insts.instance(i).value(numAttrs - 1) > 0) {
                        insts.instance(i).setValue(numAttrs - 1, 1);
                        
                        insts.instance(i).SetExtra("1");
                    } else {
                        insts.instance(i).setValue(numAttrs - 1, 0);
                            insts.instance(i).SetExtra("0");
                    }
                }
            }
            else
            {
                for (int i = 0; i < num; i++) {
                    insts.instance(i).SetExtra(String.valueOf((int)insts.instance(i).value(numAttrs - 1)));                    
                }
            }
            
            insts.setClassIndex(numAttrs - 1);
            return insts;

        } catch (Exception e) {
            System.out.println(e);
            System.out.println(files);
        }
        return null;
    }

    
    public static double[] getResults(ArrayList<Prediction> vec, double cf) {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;
        for (int p = 0; p < vec.size(); p++) {

            NominalPrediction np = (NominalPrediction) vec.get(p);

            double geo = np.actual();
            double res = np.distribution()[1];

            int actInt, resInt;
            if (geo >= cf) {
                geo = 1;
                actInt = 1;
            } else {
                geo = 0;
                actInt = 0;
            }

            if (res >= cf) {
                res = 1;
                resInt = 1;
            } else {
                res = 0;
                resInt = 0;
            }

            if (actInt == 0 && resInt == 0) {
                tn += 1;
            } else if (actInt > 0 && resInt > 0) {
                tp += 1;
            } else if (actInt == 0 && resInt > 0) {
                fp += 1;
            } else if (actInt > 0 && resInt == 0) {
                fn += 1;
            }
        }

        return new double[]{tp, tn, fp, fn};
    }
    
    public static double[] getResults(ArrayList<Prediction> vec) {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;
        for (int p = 0; p < vec.size(); p++) {

            NominalPrediction np = (NominalPrediction) vec.get(p);

            double geo = np.actual();
            double res = np.distribution()[1];

            int actInt, resInt;
            if (geo >= cf) {
                geo = 1;
                actInt = 1;
            } else {
                geo = 0;
                actInt = 0;
            }

            if (res >= cf) {
                res = 1;
                resInt = 1;
            } else {
                res = 0;
                resInt = 0;
            }

            if (actInt == 0 && resInt == 0) {
                tn += 1;
            } else if (actInt > 0 && resInt > 0) {
                tp += 1;
            } else if (actInt == 0 && resInt > 0) {
                fp += 1;
            } else if (actInt > 0 && resInt == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }

    public static double[] getResults(double actual[], double[] predicted) {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;
        for (int p = 0; p < actual.length; p++) {

            //NominalPrediction np = (NominalPrediction) vec.elementAt(p);
            double geo = actual[p];
            double res = predicted[p];
            int actInt, resInt;
            if (geo >= cf) {
                geo = 1;
                actInt = 1;
            } else {
                geo = 0;
                actInt = 0;
            }

            if (res >= cf) {
                res = 1;
                resInt = 1;
            } else {
                res = 0;
                resInt = 0;
            }

            if (actInt == 0 && resInt == 0) {
                tn += 1;
            } else if (actInt > 0 && resInt > 0) {
                tp += 1;
            } else if (actInt == 0 && resInt > 0) {
                fp += 1;
            } else if (actInt > 0 && resInt == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }
    
    
    public static double[] getResults(double actual[], double[] predicted, double cfs[]) {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;
        for (int p = 0; p < actual.length; p++) {

            //NominalPrediction np = (NominalPrediction) vec.elementAt(p);
            double geo = actual[p];
            double res = predicted[p];
            double cf = cfs[p];
            int actInt, resInt;
            if (geo >= cf) {
                geo = 1;
                actInt = 1;
            } else {
                geo = 0;
                actInt = 0;
            }

            if (res >= cf) {
                res = 1;
                resInt = 1;
            } else {
                res = 0;
                resInt = 0;
            }

            if (actInt == 0 && resInt == 0) {
                tn += 1;
            } else if (actInt > 0 && resInt > 0) {
                tp += 1;
            } else if (actInt == 0 && resInt > 0) {
                fp += 1;
            } else if (actInt > 0 && resInt == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }

    public static boolean SaveToCsv(Instances instances, String name) throws Exception
    {
        
        String name2 = name;
        
        FileWriter fout = new FileWriter(name2);
        
        for (int i = 0;i<instances.numInstances();i++)
        {
            String out = Arrays.toString(instances.instance(i).toDoubleArray())+"\n";
            fout.write(out);
        }
        fout.flush();
        fout.close();
        return true;
    }
            
    public static String Instance2Str(Instance inst)
    {
        StringBuilder out = new StringBuilder("");
        for (int i  = 0;i<inst.numAttributes()-1;i++)
        {
            out.append(String.format("%.2f", inst.value(i))).append(",");
        }
        out.append(String.format("%.1f",inst.classValue()));
        String outStr = out.toString();
        out = null;
        return outStr;
    }
    
    public static Instances getUniqueInstances(Instances in)
    {
        Instances out = new Instances(in,0);
        HashSet<String> s = new HashSet<>();
        for (int i =0;i<in.numInstances();i++)
        {
            String insStr = Instance2Str(in.instance(i));            
            if (s.contains(insStr))
                continue;
            out.add(in.instance(i));
            s.add(insStr);
        }
        
        s.clear();
        s = null;
        return out;
    }
    
    
    public static Instances getUniqueInstancesInPlace(Instances in)
    {
        HashSet<String> s = new HashSet<>();
        int i = 0;
        while(i<in.numInstances())
        {
            String insStr = Instance2Str(in.instance(i));            
            if (!s.contains(insStr))
            {
                s.add(insStr);
                i+=1;
                continue;
            }                                
            in.delete(i);
        }
        
        s.clear();
        s = null;
        return in;
    }
    
    
    public static Instances Combine(ArrayList<Instances> allds, ArrayList<Integer> inds) {
        try {
            Instances ret = new Instances(allds.get(inds.get(0)), 0);
            for (int ind : inds) {
                for (int i = 0; i < allds.get(ind).numInstances(); i++) {
                    ret.add(allds.get(ind).instance(i));
                }
            }
            return new Instances(ret);
        } catch (Exception ee) {
            ee.printStackTrace();
            return null;
        }
    }


    public static Instances NNFilter(Instances train, Instances test, int count) throws Exception {
        Instances trainCopy = new Instances(train);
        Instances testCopy = new Instances(test);
        trainCopy.setClassIndex(-1);
        testCopy.setClassIndex(-1);
        trainCopy.deleteAttributeAt(trainCopy.numAttributes() - 1);
        testCopy.deleteAttributeAt(testCopy.numAttributes() - 1);
        Instances out = new Instances(train, 0);
        out.setClassIndex(train.numAttributes()-1);
        LinearNNSearch knn = new LinearNNSearch(trainCopy);

        
        Set<Integer> instSet = new HashSet<Integer>();
        Set<String> instSetStr = new HashSet<String>();
        String ID = "";
        
        
        for (int i = 0; i < test.numInstances(); i++) {
            Instances nearestInstances = knn.kNearestNeighbours(testCopy.instance(i), count);

            for (int j = 0; j < Math.min(nearestInstances.numInstances(), count); j++) {

                ID = nearestInstances.instance(j).GetID();
                if (instSetStr.contains(ID)) {
                    continue;
                }
                out.add(train.instance(nearestInstances.instance(j).GetInstIndex()));
                instSetStr.add(ID);


            }
            nearestInstances = null;
        }
        
        trainCopy = null;
        testCopy = null;
        knn = null;
        instSet = null;
        instSetStr = null;
        
        return out;
    }


    public static double[] getResultsSet(ArrayList<ArrayList<Prediction>> preds, Instances tss, boolean cluster, ArrayList<Double> w) throws Exception {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;

        int num = tss.numInstances();
        int numAttrs = tss.numAttributes();

        for (int i = 0; i < num; i++) {
            double geo = tss.instance(i).value(numAttrs - 1);

            ArrayList<Double> lss = new ArrayList<Double>();

            for (int k = 0; k < preds.size(); k++) {
                double v = ((NominalPrediction) preds.get(k).get(i)).distribution()[1];

                lss.add(v);
            }

            double res = 0;
            if (cluster) {
                //Cluester 
            } else {
                for (double val : lss) {
                    res += val;
                }
                res /= lss.size();

            }

            if (geo >= cf) {
                geo = 1;
            } else {
                geo = 0;
            }

            if (res >= cf) {
                res = 1;
            } else {
                res = 0;
            }

            if (geo == 0 && res == 0) {
                tn += 1;
            } else if (geo > 0 && res > 0) {
                tp += 1;
            } else if (geo == 0 && res > 0) {
                fp += 1;
            } else if (geo > 0 && res == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }

    public static double[] getResultsSet(ArrayList<ArrayList<Prediction>> preds, Instances tss, boolean cluster) throws Exception {
        double tp = 0.0, fp = 0.0, tn = 0.0, fn = 0.0;

        int num = tss.numInstances();
        int numAttrs = tss.numAttributes();

        for (int i = 0; i < num; i++) {
            double geo = tss.instance(i).value(numAttrs - 1);

            ArrayList<Double> lss = new ArrayList<Double>();

            for (int k = 0; k < preds.size(); k++) {
                double v = ((NominalPrediction) preds.get(k).get(i)).distribution()[1];

                lss.add(v);
            }

            double res = 0;
            if (cluster) {
                //Cluster
            } else {
                for (double val : lss) {
                    res += val;
                }
                res /= lss.size();

            }

            if (geo >= cf) {
                geo = 1;
            } else {
                geo = 0;
            }

            if (res >= cf) {
                res = 1;
            } else {
                res = 0;
            }

            if (geo == 0 && res == 0) {
                tn += 1;
            } else if (geo > 0 && res > 0) {
                tp += 1;
            } else if (geo == 0 && res > 0) {
                fp += 1;
            } else if (geo > 0 && res == 0) {
                fn += 1;
            }

        }

        return new double[]{tp, tn, fp, fn};
    }

    public static ArrayList<IChrm> MySort(ArrayList<IChrm> hmm) {
        
        Collections.sort(hmm, new Comparator<IChrm>() {
            @Override
            public int compare(IChrm t, IChrm t1) {
                double tf1 = t.getFitness();
                double tf2 = t1.getFitness();
                if (tf1<tf2)
                    return 1;
                else if (tf1>tf2)
                    return -1;
                else
                    return 0;
            }
        });
        
        return hmm;
    }
    
    
    public static ArrayList<ArrayList<IChrm>> CombinePops(ArrayList<IChrm> hmm, ArrayList<IChrm> newHMM) {
        int i = 0;
        int j = 0;
        ArrayList<IChrm> ret = new ArrayList<IChrm>();
        ArrayList<IChrm> del = new ArrayList<IChrm>();
        while (ret.size() < hmm.size()) {
            if (hmm.get(i).getFitness() >= newHMM.get(j).getFitness()) {
                ret.add(hmm.get(i));
                i += 1;
            } else {
                ret.add(newHMM.get(j));
                j += 1;
            }
        }

        while (del.size() < hmm.size()) {
            if (i < hmm.size() && j < newHMM.size()) {

                if (hmm.get(i).getFitness() >= newHMM.get(j).getFitness()) {
                    del.add(hmm.get(i));
                    i += 1;

                } else {
                    del.add(newHMM.get(j));
                    j += 1;

                }
            } else if (i < hmm.size()) {
                del.add(hmm.get(i));
                i += 1;
            } else {
                del.add(newHMM.get(j));
                j += 1;
            }
        }
        ArrayList<ArrayList<IChrm>> retful = new ArrayList<ArrayList<IChrm>>();
        retful.add(ret);
        retful.add(del);
        return retful;
    }
    
    
    public static String getStats(Instances set, boolean extIDS, boolean extExts, boolean extChrs) {
        return "";
    }
    
    
    public static double attMean(Instances ds, int attIndex) {
        double sum = 0;
        for (int i = 0; i < ds.numInstances(); i++) {
            sum += ds.instance(i).value(attIndex);
        }
        return sum / ds.numInstances();
    }


    public static double[] getMeasures(double[] vals) {
        double tp = vals[0], tn = vals[1], fp = vals[2], fn = vals[3];
        double prec = 0.0, accu = 0.0, recall = 0.0, gm = 0.0, bac = 0.0;
        if (tp + fn != 0) {
            recall = tp / (tp + fn);
        }

        if (tp + fp != 0) {
            prec = tp / (tp + fp);
        }

        if (tp + fp + tn + fn != 0) {
            accu = (tp + tn) / (tp + fp + tn + fn);
        }


        double F = 0;
        if (prec + recall != 0) {
            F = (2.0 * prec * recall) / (prec + recall);
        }

        return new double[]{recall, prec, accu, F};

    }
    
    
    public static HashMap<String, Double> getExtMeasures(double[] vals) {
        HashMap<String, Double> measures = new HashMap<>();
        double tp = vals[0], tn = vals[1], fp = vals[2], fn = vals[3];
        double prec = 0.0, accu = 0.0, recall = 0.0, gm = 0.0, bac = 0.0;
        if (tp + fn != 0) {
            recall = tp / (tp + fn);
        }
        
        measures.put("rec", recall);

        if (tp + fp != 0) {
            prec = tp / (tp + fp);
        }

        measures.put("prec", prec);
        
        if (tp + fp + tn + fn != 0) {
            accu = (tp + tn) / (tp + fp + tn + fn);
        }
        
        measures.put("accu", accu);
        

        double F = 0;
        if (prec + recall != 0) {
            F = (2.0 * prec * recall) / (prec + recall);
        }
        measures.put("F", F);
        


        if(recall+4*prec>0) 
            measures.put("F2", 5*recall*prec/(recall+4*prec));
        else
            measures.put("F2",0.0);

        if(recall+0.25*prec>0) 
            measures.put("F0.5",  1.25*recall*prec/(recall+0.25*prec));
        else
            measures.put("F0.5",0.0);

        double pf= 0.0;
        if (fp+tn!=0)
        {
            pf = fp/(fp+tn);
        }

        measures.put("pf" ,pf);


        measures.put("bal", 1-(Math.sqrt(pf*pf+(1-recall)*(1-recall))/Math.sqrt(2)));

        double mcsq = Math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn));

        if (mcsq!=0)
            measures.put("mcc",(tp*tn-fp*fn)/mcsq);
        else
            measures.put("mcc",0.0);


        if (tn+fp!=0)
            measures.put("tnr", tn/(tn+fp));
        else
            measures.put("tnr", 0.0);


        if (fn+tp!=0)
            measures.put("fnr",  fn/(fn+tp));
        else
            measures.put("fnr", 0.0);


        measures.put("GMean1", Math.sqrt(recall*prec));
        measures.put("GMean2", Math.sqrt(recall*(1-pf)));       

        return measures;

    }
    

    public static Instances List2Instances(ArrayList<Double> data) {

        int numInstances = data.size();
        int numDimensions = 1;
        FastVector atts = new FastVector();
        ArrayList<Instance> instances = new ArrayList<Instance>();
        for (int dim = 0; dim < numDimensions; dim++) {
            Attribute current = new Attribute("Attribute" + String.valueOf(dim), dim);
            if (dim == 0) {
                for (int obj = 0; obj < numInstances; obj++) {
                    instances.add(new SparseInstance(numDimensions));
                }
            }

            for (int obj = 0; obj < numInstances; obj++) {
                instances.get(obj).setValue(current, data.get(obj));
            }

            atts.addElement(current);
        }
        Instances newDataset = new Instances("Dataset", atts, atts.size());

        for (Instance inst : instances) {
            newDataset.add(inst);
        }
        return newDataset;
    }      
    

    public static Instance FindInstance(Instance ins, Instances set) {
        for (int i = 0; i < set.numInstances(); i++) {
            boolean eq = true;
            for (int j = 0; j < ins.numAttributes(); j++) {
                if (ins.value(j) != set.instance(i).value(j)) {
                    eq = false;
                    break;

                }
            }
            if (eq) {
                return set.instance(i);
            }
        }
        return null;
    }

    public static int FindInstanceIndex(Instance ins, Instances set) {
        for (int i = 0; i < set.numInstances(); i++) {
            boolean eq = true;
            for (int j = 0; j < ins.numAttributes(); j++) {
                if (ins.value(j) != set.instance(i).value(j)) {
                    eq = false;
                    break;

                }
            }
            if (eq) {
                return i;
            }
        }
        return -1;
    }

    public static int FindInstanceIndexNoLabel(Instance ins, Instances set) {
        for (int i = 0; i < set.numInstances(); i++) {
            boolean eq = true;
            for (int j = 0; j < ins.numAttributes() - 1; j++) {
                if (ins.value(j) != set.instance(i).value(j)) {
                    eq = false;
                    break;

                }
            }
            if (eq) {
                return i;
            }
        }
        return -1;
    }

    public static int FindInstanceIndexSimple(Instance ins) {

        return ins.GetInstIndex();
    }

    public static HashSet<Integer> FindAllSimilarInstancesIndexes(int index, Instances set) {

        
        
        HashSet<Integer> indexSet = new HashSet<Integer>();
        Instance ins = set.instance(index);
    
        
        for (int i = 0; i < set.numInstances(); i++) {

            if (ins.GetID().compareTo(set.instance(i).GetID()) == 0) {
                indexSet.add(i);
            }
        }
        return indexSet;
    }
    
    
    public static HashSet<Integer> FindAllSimilarInstancesIndexesNoID(int index, Instances set) {

        HashSet<Integer> indexSet = new HashSet<Integer>();
        Instance ins = set.instance(index);
        for (int i = 0; i < set.numInstances(); i++) {
            if (i == index) {
                indexSet.add(i);
                continue;
            }
            boolean eq = true;
            for (int j = 0; j < ins.numAttributes() - 1; j++) {
                if (ins.value(j) != set.instance(i).value(j)) {
                    eq = false;
                    break;

                }
            }
            if (eq) {
                indexSet.add(i);
            }
        }
        return indexSet;
    }  

}
