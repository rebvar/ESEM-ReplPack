/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Helpers;

import java.util.ArrayList;

/**
 *
 * @author sehossei
 */
public class Generic {
    public static String join(ArrayList<String> lst) 
    {
        
        return String.join(",", lst);
    }
}
