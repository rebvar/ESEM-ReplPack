/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LSH;

import weka.core.Instances;
import info.debatty.java.lsh.*;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import wdp2.DPLIB;
import wdp2.IChrm;
import GIS.CHRM_GIS;
import wdp2.GLOB;
import weka.classifiers.AbstractClassifier;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.Prediction;



/**
 *
 * @author sehossei
 */
public class LSHCreateBinary {

    public String file;
    public FileWriter fout;
    public Object CreateBucketsTune(Instances trainSet, Instances testSet, ArrayList<Instances> vSets, String name, boolean testCut, int iternum, boolean save, boolean superbit, String clfName, boolean tunelrn) throws Exception {                
        CHRM_GIS best = null;
        int bestStages = 0;
        int bestBuckets = 0;
        double spentTimeIS = 0;
        double tempTime = 0;
        for (int i = 0;i<10;i++)
        {
            int stages = DPLIB.rnd.nextInt(20)+1;
            int buckets = DPLIB.rnd.nextInt(100)+3;
            CHRM_GIS chrm = null;
            while (true)
            {
                chrm = (CHRM_GIS)CreateBuckets(trainSet, testSet, vSets, name, testCut, iternum, save, superbit, stages, buckets, false, clfName, tunelrn);
                if (chrm != null)
                    break;
            }
            
            spentTimeIS+=(double)chrm.extra.get("SPENT-TIME-IS");
            
            if (best == null)
            {
                best = chrm;
                bestBuckets = buckets;
                bestStages = stages;
            }
            else
            {
                if (chrm.getFitness()>best.getFitness())
                {
                    best = chrm;
                    bestBuckets = buckets;
                    bestStages = stages;
                }
            }           
        }
        
        CreateBuckets(trainSet, testSet, vSets, name, testCut, iternum, save, superbit, bestStages, bestBuckets, true,clfName, tunelrn);
        
        System.out.println("#TIME-FOR-IS:"+name+":" + file + ": "+spentTimeIS);
        fout.write("#TIME-FOR-IS:"+name+":" + file + ": "+String.valueOf(spentTimeIS)+"\n");        
        return best;
        
        
    }
    
    public Object CreateBuckets(Instances trainSet, Instances testSet, ArrayList<Instances> vSets, String name, boolean testCut, int iternum, boolean save, boolean superbit, int stages, int buckets, boolean print, String clfName, boolean tunelrn) throws Exception {
        
        double spentIsTime = 0;
        double tempTime;
        
        if (vSets == null)
        {
            vSets = new ArrayList<>();
            vSets.add(trainSet);
        }
        
        
        tempTime = System.currentTimeMillis();
        int count = trainSet.numInstances();
        HashMap<Integer, Instances> bins = new HashMap<>();
        
        int n = trainSet.numAttributes();
        
        int binid = 0;
        LSHMinHash lshmin = new LSHMinHash(stages, buckets, n);
        LSHSuperBit lshsuper = new LSHSuperBit(stages, buckets, n);
        double sp = 0.75;
        
        for (int i = 0; i < count; i++) {
            double[] vector = trainSet.instance(i).toDoubleArray();
            boolean[] vecBool = new boolean[vector.length];
            if (!superbit)
            {
                //Convert To Boolean for MinHash.
                
                //First do min max norm;
                
//                for (int k = 0;k<vector.length;k++)
//                {    
//                    if (vector[k]>sp)
//                        vecBool[k] = true;
//                    else
//                        vecBool[k] = false;
//
//                }
            }
            int[] hash = null;
            if (superbit)
                hash = lshsuper.hash(vector);
            else 
                hash = lshmin.hash(vecBool);
            binid = hash[0];
            if (!bins.containsKey(binid)) {
                bins.put(binid, new Instances(trainSet, 0));
            }

            bins.get(binid).add(trainSet.instance(i));
        }
        
        spentIsTime+=System.currentTimeMillis()-tempTime;
        
        int numBins = bins.size();
        if (print)
        {
            System.out.println("#Number of BINS:" + numBins);
            fout.write("#Number of BINS:" + String.valueOf(numBins)+"\n");
        }
        ArrayList<IChrm> pop = new ArrayList<>();        
        
        
        Iterator it = bins.keySet().iterator();
        while(it.hasNext())
        {
            int i = (int)it.next();
            Instances trSet = bins.get(i);
            GLOB g = new GLOB(clfName, tunelrn);
            Classifier l; 
            if (tunelrn)
            {
                l = g.getTunedCLF(trSet, vSets,fout,name, file);
            }
            else
            {
                l = g.getClassifier();
            }
            l.buildClassifier(trSet);
        
            int j = 0;
            
            ArrayList<double[]> allvecs = new ArrayList<double[]>();
            ArrayList<double[]> confs = new ArrayList<double[]>();

            double valsA[] = null;
            double confsA[] = null;
            for (Instances vSet : vSets) {
        
                Evaluation evaluation = new Evaluation(trSet);
                if (vSet != null)
                {
                    evaluation.evaluateModel(l, vSet, new Object[0]);
                }
                else
                {
                    evaluation.evaluateModel(l, trSet, new Object[0]);
                }
                
                ArrayList<Prediction> vec = evaluation.predictions();
                double vals[] = null;
                if (testCut){
                    
                    //Do testCut
                    
                }
                else
                {
                    vals = DPLIB.getResults(vec);
                    
                    if (confsA==null)
                    {
                        confsA = new double[vals.length];
                         for (j = 0; j < confsA.length; j++) {
                            confsA[j] = 0;
                        }   
                    }
                    
                    for (j = 0; j < confsA.length; j++) {
                        confsA[j] += vals[j];
                    } 
                    
                    confs.add(vals);
                    
                    vals = DPLIB.getMeasures(vals);
                }
                
                allvecs.add(vals);
                
                if (valsA == null) {
                    valsA = new double[vals.length];
                    for (j = 0; j < valsA.length; j++) {
                        valsA[j] = 0;
                    }
                }

                for (j = 0; j < vals.length; j++) {
                    valsA[j] += vals[j];
                }
            }
            for (j = 0; j < valsA.length; j++) {
                valsA[j] = valsA[j] / vSets.size();
            }
            
            for (j = 0; j < confsA.length; j++) {
                confsA[j] = confsA[j] / vSets.size();
            }
                       
            CHRM_GIS h = new CHRM_GIS(trSet, valsA, 0);
            h.fitnesses = allvecs;
            h.conf = confsA;
            h.confs = confs;
            
            h.bestCF = DPLIB.cf;
            
            pop.add(h);
            l = null;
        }
        
        tempTime = System.currentTimeMillis();
        pop = DPLIB.MySort(pop);
        spentIsTime+= System.currentTimeMillis() - tempTime;
        CHRM_GIS top = (CHRM_GIS) pop.get(0);
        
        if (print)
        {
            System.out.println("#Instances in Top:" + top.ds.numInstances());
            fout.write("#Instances in Top:" + String.valueOf(top.ds.numInstances())+"\n");
        }
        if (print)
        {
            System.out.println("#STAGES:" + stages);
            System.out.println("#BUCKETS:" + buckets);
            System.out.println("#BEST-CF-VALUE:" + top.bestCF);
            fout.write("#STAGES:" + stages);fout.write("\n");
            fout.write("#BUCKETS:" + buckets);fout.write("\n");
            fout.write("#BEST-CF-VALUE:" + top.bestCF);fout.write("\n");
        }
        
        GLOB g = new GLOB(clfName, tunelrn);
        Classifier l; 
        if (tunelrn)
        {
            l = g.getTunedCLF(top.ds, vSets,fout,name, file);
            if(print)
            {
                System.out.print("#TUNE-LRN-PARAMS-"+name+":" + file + ": ");                
                System.out.println(Arrays.toString(g.selectedParams));                
                fout.write("#TUNE-LRN-PARAMS-"+name+":" + file + ": ");
                fout.write(Arrays.toString(g.selectedParams));fout.write("\n");                
                String sCheck[]= g.getCLFOptions();                
                
                System.out.print("#SETSET-LRN-PARAMS-"+name+":" + file + ": ");                
                System.out.println(Arrays.toString(sCheck));                                
                fout.write("#SETSET-LRN-PARAMS-"+name+":" + file + ": ");                
                fout.write(Arrays.toString(sCheck));fout.write("\n");
                
            }
        }
        else
        {
            l = g.getClassifier();
        }
        
        l.buildClassifier(top.ds);
        Evaluation evaluation = new Evaluation(top.ds);
        evaluation.evaluateModel(l, testSet, new Object[0]);
        
        ArrayList<Prediction> vec = evaluation.predictions();
        double [] vals = DPLIB.getResults(vec,top.bestCF);
        if (print)
        {    
            System.out.print("#CONF-TEST-"+name+":" + file + ": ");
            System.out.println(Arrays.toString(vals));
            fout.write("#CONF-TEST-"+name+":" + file + ": ");
            fout.write(Arrays.toString(vals));fout.write("\n");
        }
        
        vals = DPLIB.getMeasures(vals);                
        if (print)
        {            
            System.out.println("#LSH-FOR-TOP-ONLY");
            System.out.print(name+":" + file + ": ");
            System.out.println(Arrays.toString(vals));
            
            
            fout.write("#LSH-FOR-TOP-ONLY");fout.write("\n");            
            fout.write(name+":" + file + ": ");
            fout.write(Arrays.toString(vals));fout.write("\n");                                    
        }
        
        for (int i = 0;i< pop.size();i++)
        {
            pop.set(i, null);
        }
        
        pop = null;
        
        it = bins.keySet().iterator();
        while(it.hasNext())
        {
            int i = (int)it.next();
            
            bins.replace(i, null);            
            
        }        
        
        bins = null;              
        
        
        if (name.indexOf("LSHTune")<0 && print)
        {            
            System.out.println("#TIME-FOR-IS:"+name+":" + file + ": "+spentIsTime);
            fout.write("#TIME-FOR-IS:"+name+":" + file + ": "+String.valueOf(spentIsTime)+"\n");
        }
        
        top.addToExtra("SPENT-TIME-IS", (double)spentIsTime);
        
        return top;

    }
    
        
}
