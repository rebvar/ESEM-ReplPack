/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GIS;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import wdp2.DPLIB;
import wdp2.GLOB;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.Prediction;
import weka.core.Instances;
import wdp2.IChrm;
import weka.classifiers.Classifier;

/**
 *
 * @author sehossei
 */
public class GIS {

    
    
    public int popSize = 40;
    public double chrmSize = 0.01D;
    
    public int folds = 10;
    public int numGens = 20;

    public int numParts = 1;

    public int sizeTopP = 0;
    public int iters;
    public int count = 1;
    public boolean doCluster = false;

    
    public String file;

    public boolean GIS(Instances trainSeti, Instances testSeti, String name, FileWriter fout,  ArrayList<Instances> vSets, int vSetType, boolean fixedTrainSize, boolean log, boolean ignoreOK, Double threshold, ArrayList<Double> thresholds, ArrayList<Double> rejectedFits, ArrayList<Double[]> rejectedPerfs, ArrayList<Double[]> rejectedTestPerfs, String clfName) throws Exception {                 
        double tempTime;
        double  spentISTime = 0;
        
        ArrayList<ArrayList<Prediction>> preds = new ArrayList();
        ArrayList<IChrm> pop = new ArrayList();
        

        Instances trainSet = new Instances(trainSeti);
        Instances testSet = new Instances(testSeti);
        pop.clear();

        int tstSize = testSet.numInstances();
        int partSize = (int) Math.floor(tstSize / numParts);
        preds.clear();        
        
        
        
        
        boolean isOK = true;
        
        
        Random rnd = new Random(System.currentTimeMillis());
        testSet.randomize(rnd);
        for (int p = 0; p < numParts; p++) 
        {
            ArrayList<Double> diffp = new ArrayList<>();
        
            
            
            System.out.print("\n"+String.valueOf(p) + ": ");
            fout.write("\n"+String.valueOf(p) + ": ");
            
            tempTime = System.currentTimeMillis();
            pop.clear();
            int start = p * partSize;
            int end = (p + 1) * partSize;
            if (end > tstSize) {
                end = tstSize;
            }
            if (p == numParts - 1) {
                end = tstSize;
            }

            Instances testPart = new Instances(testSet, 0);
            for (int t = start; t < end; t++) {
                testPart.add(testSet.instance(t));
            }
            
            spentISTime += System.currentTimeMillis() - tempTime;
            
            HashSet<Integer> uinds = new HashSet<Integer>();
            if (vSets==null || vSets.size()==0)
            {
                Instances vSet = null;
                if (vSets == null)
                    vSets = new ArrayList<>();
                
                if (vSetType==0)
                {
                    vSet = trainSeti;                                        
                }
                else if (vSetType==1)
                {
                    
                    tempTime = System.currentTimeMillis();
                    vSet = DPLIB.NNFilter(trainSet, testPart, 10);
                    spentISTime+=System.currentTimeMillis() - tempTime;
                    
                }
                vSets.add(vSet);
            }
            
            
            for (int i = 0; i < popSize; i++) {
                tempTime = System.currentTimeMillis();
                uinds.clear();
                
                int size;
                
                if (fixedTrainSize)
                    size = (int) (trainSet.numInstances() * chrmSize); 
                else
                    size = DPLIB.rnd.nextInt((int) (trainSet.numInstances() * chrmSize))+100;
                
                
                
                Instances trSet = new Instances(trainSet, 0);
                int j = 0;
                while (j < size) {
                    int index = DPLIB.rnd.nextInt(trainSet.numInstances());
                    trSet.add(trainSet.instance(index));
                    
                    if (!uinds.contains(index)) {
                        uinds.add(index);
                    }

                    j++;
                }
                
                spentISTime += System.currentTimeMillis() - tempTime;
                
                
                tempTime = System.currentTimeMillis();
                
                Classifier l = new GLOB(clfName).getClassifier();
                l.buildClassifier(trSet);
                Evaluation evaluation = new Evaluation(trSet);
                
                
                j = 0;
                
                ArrayList<double[]> allvecs = new ArrayList<double[]>();
                                
                double valsA[] = null;
                ArrayList<double[]> allconfs = new ArrayList<double[]>();
                double confsA[] = null;
                for (Instances vSet: vSets)
                {

                    evaluation.evaluateModel(l, vSet, new Object[0]);
                    ArrayList<Prediction> vec = evaluation.predictions();
                    double[] vals1 = DPLIB.getResults(vec);
                    
                    allconfs.add(vals1);
                    
                    double[] vals = DPLIB.getMeasures(vals1);

                    allvecs.add(vals);

                    if (valsA == null)
                    {
                        valsA = new double[vals.length];
                        confsA = new double[vals1.length];
                        for (j=0;j<valsA.length;j++)
                        {
                            valsA[j] = 0;                            
                        }
                        
                        for (j=0;j<confsA.length;j++)
                        {
                            confsA[j] = 0;                            
                        }
                        
                    }   

                    for (j=0;j<vals.length;j++)
                    {
                        valsA[j] += vals[j];                        
                    }

                    for (j=0;j<vals1.length;j++)
                    {
                        confsA[j] += vals1[j];                        
                    }
                    
                    
                    
                    
                }
                for (j=0;j<valsA.length;j++)
                    valsA[j] = valsA[j]/vSets.size();

                for (j=0;j<confsA.length;j++)
                    confsA[j] = confsA[j]/vSets.size();
                                
                CHRM_GIS h = new CHRM_GIS(trSet, valsA, 0);
                h.fitnesses = allvecs;
                h.confs = allconfs;
                h.conf = confsA;
                pop.add(h);
                
                spentISTime += System.currentTimeMillis() - tempTime;
                
            }
            
            tempTime = System.currentTimeMillis();
            pop = DPLIB.MySort(pop);
            spentISTime += System.currentTimeMillis() - tempTime;
            
            int cnt = 0;
            int g = 0;
            for (g = 0; g < numGens; g++) {
                System.out.print(String.valueOf(g)+" ");
                fout.write(String.valueOf(g)+" ");
                
                tempTime = System.currentTimeMillis();
                ArrayList<IChrm> newPop = new ArrayList();
                for (int i = 0; i < sizeTopP; i++) {
                    newPop.add(pop.get(i));
                }
                
                for (int i = 0; i < pop.size() - sizeTopP; i += 2) {
                    int idx1 = 0;
                    int idx2 = 0;
                    while (idx1 == idx2) {
                        if (cnt >= 3) {
                            idx1 = rnd.nextInt(pop.size());
                            idx2 = rnd.nextInt(pop.size());
                        } else {
                            idx1 = GA.tornament(pop);
                            idx2 = GA.tornament(pop);
                            cnt++;
                        }
                    }
                    cnt = 0;
                    Instances ds1 = ((CHRM_GIS) pop.get(idx1)).ds;
                    Instances ds2 = ((CHRM_GIS) pop.get(idx2)).ds;

                    Instances[] ret = GA.crossOver(ds1, ds2,fixedTrainSize);
                    ds1 = ret[0];
                    ds2 = ret[1];
                    ds1 = GA.Mutate(ds1);
                    ds2 = GA.Mutate(ds2);
                    newPop.add(new CHRM_GIS(ds1, null));
                    newPop.add(new CHRM_GIS(ds2, null));
                }
                
                spentISTime += System.currentTimeMillis() - tempTime;
                
                for (int i = 0; i < newPop.size(); i++) {
                    
                    tempTime = System.currentTimeMillis();
                    
                    Classifier l = new GLOB(clfName).getClassifier();
                    l.buildClassifier(((CHRM_GIS) newPop.get(i)).ds);
                    Evaluation evaluation = new Evaluation(((CHRM_GIS) newPop.get(i)).ds);
                    
                    int j = 0;
                    
                    ArrayList<double[]> allvecs = new ArrayList<double[]>();
                    ArrayList<double[]> allconfs = new ArrayList<double[]>();
                    
                    double valsA[] = null;
                    double confsA[] = null;
                    for (Instances vSet: vSets)
                    {
                        evaluation.evaluateModel(l, vSet, new Object[0]);
                        ArrayList<Prediction> vec = evaluation.predictions();
                        double[] vals1 = DPLIB.getResults(vec);
                        allconfs.add(vals1);
                        
                        double[] vals = DPLIB.getMeasures(vals1);

                        allvecs.add(vals);

                        if (valsA == null)
                        {
                            valsA = new double[vals.length];
                            confsA = new double[vals.length];
                            for (j=0;j<valsA.length;j++)
                                valsA[j] = 0;
                            for (j=0;j<confsA.length;j++)
                                confsA[j] = 0;
                            
                        }   

                        for (j=0;j<vals.length;j++)
                            valsA[j] += vals[j];
                        for (j=0;j<vals1.length;j++)
                            confsA[j] += vals1[j];

                        
                        
                        
                    }
                    for (j=0;j<valsA.length;j++)
                        valsA[j] = valsA[j]/vSets.size();


                    
                    for (j=0;j<confsA.length;j++)
                        confsA[j] = confsA[j]/vSets.size();
                    
                    
                    
                    ((CHRM_GIS) newPop.get(i)).fitness = valsA;
                    ((CHRM_GIS) newPop.get(i)).fitnesses = allvecs;
                    ((CHRM_GIS) newPop.get(i)).confs = allconfs;
                    ((CHRM_GIS) newPop.get(i)).conf = confsA;
                    
                    spentISTime += System.currentTimeMillis() - tempTime;
                    
                }
                
                tempTime = System.currentTimeMillis();
                
                newPop = DPLIB.MySort(newPop);
                boolean exit = false;
                int countComp = 0;
                
                ArrayList<ArrayList<IChrm>> rets = DPLIB.CombinePops(pop, newPop);
                
                ArrayList<IChrm> del = rets.get(1);
                
                newPop = rets.get(0);
                
                double diff = Math.abs(GA.GetMeanFittness(pop, countComp) - GA.GetMeanFittness(newPop, countComp));
                if (diff < 1.0E-4D) {
                    exit = true;
                }
                
                diffp.add(diff);
                
                pop = newPop;
                if ((((CHRM_GIS) pop.get(0)).getFitness() > 0.0D) && (exit)) {
                    break;
                }
                exit = false;
                spentISTime += System.currentTimeMillis() - tempTime;
            }
            
            
            ArrayList<Double> w = new ArrayList();
            if (count == 0) {
                count = pop.size();
            }
            for (int i = 0; i < count; i++) {
                Classifier l = new GLOB(clfName).getClassifier();
                Instances tds = ((CHRM_GIS) pop.get(i)).ds;
                Instances testPartI = testPart;



                l.buildClassifier(tds);
                Evaluation evaluation = new Evaluation(tds);
                evaluation.evaluateModel(l, testPartI, new Object[0]);
                ArrayList<Prediction> vec = evaluation.predictions();
                if (preds.size() == count) {
                    (preds.get(i)).addAll(vec);
                } else {
                    preds.add(vec);
                }
            
            }
            
        }
        
        if (!isOK) {
            
        } else {
            thresholds.add(pop.get(0).getFitness());
        }
        
        System.out.println();
        System.out.println("Best Top Fitness:"+Arrays.toString(((CHRM_GIS)pop.get(0)).fitness));
        System.out.println("Best Fitness (mean):"+((CHRM_GIS)pop.get(0)).getMeanFitness());
        
        fout.write("\n");
        fout.write("Best Top Fitness:"+Arrays.toString(((CHRM_GIS)pop.get(0)).fitness));fout.write("\n");
        fout.write("Best Fitness (mean):"+((CHRM_GIS)pop.get(0)).getMeanFitness());fout.write("\n");
        
        
        double[] vals1 = DPLIB.getResultsSet(preds, testSet, doCluster);
        double[] vals = DPLIB.getMeasures(vals1);
        
        
        if (isOK) {
                        
            if (ignoreOK)
            {
                System.out.print("*");
                fout.write("*");
            }
        
            System.out.println();
            System.out.print("#CONF-TEST:"+name+":" + file + ": ");
            System.out.println(Arrays.toString(vals1));
            
            System.out.println();
            System.out.print(name+":" + file + ": ");
            System.out.println(Arrays.toString(vals));
            
            fout.write("\n");
            fout.write("#CONF-TEST:"+name+":" + file + ": ");
            fout.write(Arrays.toString(vals1));fout.write("\n");
            
            fout.write("\n");
            fout.write(name+":" + file + ": ");
            fout.write(Arrays.toString(vals));
                        
        }
        else
        {
            
            CHRM_GIS bestI = (CHRM_GIS)pop.get(0);
            rejectedFits.add(bestI.getFitness());
            Double[] rejVals = new Double[bestI.fitness.length];
            
            for (int i = 0;i<bestI.fitness.length;i++)
            {
                rejVals[i] = bestI.fitness[i];
            }
            rejectedPerfs.add(rejVals);
            
            Double[] testRejVals = new Double[vals.length];
            
            for (int i = 0;i<vals.length;i++)
            {
                testRejVals[i] = vals[i];
            }
            rejectedTestPerfs.add(testRejVals);
            
            
            System.out.print("#NOTOKPREDS----" + name+":" + file + ": ");
            System.out.println(Arrays.toString(vals));
            
            System.out.println();
            System.out.print("#NOTOKPREDS----"+"#CONF-TEST:"+name+":" + file + ": ");
            System.out.println(Arrays.toString(vals1));            
            
            
            fout.write("#NOTOKPREDS----" + name+":" + file + ": ");
            fout.write(Arrays.toString(vals));fout.write("\n");
            
            fout.write("\n");
            fout.write("#NOTOKPREDS----"+"#CONF-TEST:"+name+":" + file + ": ");
            fout.write(Arrays.toString(vals1));fout.write("\n");
            
        }         
                
        System.out.println("#TIME-FOR-IS:"+name+":" + file + ": "+spentISTime);
        fout.write("#TIME-FOR-IS:"+name+":" + file + ": "+String.valueOf(spentISTime)+"\n");
        
        return isOK;                        
    }
    
}
