/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GIS;

/**
 *
 * @author sehossei
 */

import java.util.ArrayList;
import java.util.HashMap;
import weka.core.Instances;
import wdp2.IChrm;
import weka.core.Instance;

public class CHRM_GIS  implements IChrm{
    public Instances ds;
    public double[] fitness;
    public ArrayList<double[]> fitnesses;
    public ArrayList<double[]> confs;
    public double auc;
    
    public double[] conf;
    public double[] testConf;
    public double[] testFitness;
    public double bestCF;
    
    public  HashMap<String, Double> extra = null;
    
    
    public void addToExtra(String key, Double val)
    {
        if (extra == null)
        {
            extra = new HashMap<>();            
        }
        
        extra.put(key, val);
    }
    
    public CHRM_GIS(Instances ds, double[] fitness)
    {
        this.ds=ds;
        this.fitness = fitness;
        auc = 0;
    }    
    
    public CHRM_GIS(Instances ds, double[] fitness, double[] conf, double testConf[], double[] testFitness)
    {
        this.ds=ds;
        this.fitness = fitness;
        this.conf = conf;
        this.testConf = testConf;
        this.testFitness = testFitness;
        auc = 0;
    }  
    
    
    @Override
    public double getFitness()
    { 
        double fit = getCustom();
        if (Double.isNaN(fit))
            return 0;        
        fit = Math.floor(fit*1000.0)/1000.0;
        
        return fit;                
    }        
    
    
    public CHRM_GIS(Instances ds, double[] fitness,double auc)
    {
        this.ds=ds;
        this.fitness = fitness;
        this.auc = auc;
    }
        
    
    public double getMin(int field)
    {
        double min = 1;
        for (int i = 0;i<fitnesses.size();i++)
        {
            if (fitnesses.get(i)[field]<min)
                min = fitnesses.get(i)[field];
        }
        
        return min;
    }
    
    
    public double getMean(int field)
    {
        double mean = 0;
        for (int i = 0;i<fitnesses.size();i++)
        {
            mean+=fitnesses.get(i)[field];
        }
        mean/=fitnesses.size();
        return mean;
    }
    
    
    public double getMeanFitness() {
        return 1/(getMean(fitness.length - 1));
    
    }
    
    
    public double getSTD(int field)
    {
        double mean = getMean(field);
        double std = 0;
        for (int i = 0;i<fitnesses.size();i++)
        {
            std+=(fitnesses.get(i)[field]-mean)*(fitnesses.get(i)[field]-mean);
        }
        
        if (std<0)
        {
            System.out.print(std);
            System.out.println("error variance");
        }
        std = Math.sqrt(std);
        return std;
    }
    
    
    
    @Override
    public double getCustom() {
        return getF()*getGMEAN();
    }
    
        
    public double MCC()
    {    
        double tp = conf[0], tn = conf[1], fp = conf[2],fn = conf[3];                
        return (tp*tn-fp*fn)/(Math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)));
    }
    
    
    public double getBalance()
    {
        double tp = conf[0], tn = conf[1], fp = conf[2],fn = conf[3];        
        double pf = (fp)/(fp+tn);
        return 1-(Math.sqrt(pf*pf+(1-fitness[0])*(1-fitness[0]))/Math.sqrt(2));        
    }
    
    
    @Override
    public double getGMEAN() {
        return Math.sqrt(fitness[1]*fitness[0]);
    }
    
    
    @Override
    public double getF() {
        return fitness[3];
    }
    
    
    public double getF_0_5() {
        return 1.25*fitness[0]*fitness[1]/(fitness[0]+0.25*fitness[1]);
    }
    
    
    
    @Override
    public double getAUC() {
        return auc;
    }
    
    @Override
    public double getBAC() {
        return fitness[2];
    }
    
    
    public double getPrecCount()
    {
        return fitness[0];
    }

    @Override
    public void SetTrSet(Instances value) {
        ds = value;
    }    
    
}