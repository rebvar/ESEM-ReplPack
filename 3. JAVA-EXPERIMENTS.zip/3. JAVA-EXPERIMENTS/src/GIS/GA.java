/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GIS;

/**
 *
 * @author sehossei
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import wdp2.DPLIB;
import weka.core.Instances;

import wdp2.IChrm;

public class GA {

    static double mProb = 0.1;
    static int mCount = 1;
    
    public static double GetMeanFittness(ArrayList<IChrm> hmm,int count)
    {
        if (count == 0)
            count = hmm.size();
        double sum = 0;
        for (int i=0;i<count;i++)
        {
            sum+=hmm.get(i).getFitness();
        }
        return sum/count;
    }
    
    public static Instances Mutate(Instances ds) {
        
        Random rnd = new Random(System.currentTimeMillis());
        double r2 = rnd.nextDouble();
        
        if (r2 <= mProb) 
        {
            
            Set<Integer> rands = new HashSet<Integer>();
            int i=0;
            
            
            
            while(i<mCount)
            {
                
                int r1 = rnd.nextInt(ds.numInstances());
                if (rands.size()==ds.numInstances())
                    return ds;
                
                if (rands.contains(r1))
                    continue;
                double instLabel = ds.instance(r1).classValue();               
                
                
                HashSet<Integer> set = DPLIB.FindAllSimilarInstancesIndexes(r1, ds);                
                Iterator<Integer> iter = set.iterator();
                while (iter.hasNext())
                {
                    r1 = iter.next();
                    
                    if ((int)ds.instance(r1).classValue()!=(int)(1-instLabel))
                        ds.instance(r1).SetExtra(ds.instance(r1).GetExtra()+"-M="+String.valueOf((int)ds.instance(r1).classValue())+">"+String.valueOf((int)(int)(1-instLabel)));
                    rands.add(r1);
                    ds.instance(r1).setClassValue(1 - instLabel);
                }
                i++;
            }
            
        }
        return ds;
    }
    
    public static int tornament(ArrayList<IChrm> hmm)
    {
        Random rnd = new Random(System.currentTimeMillis());
        int[] vals = new int[2];
        for (int i=0;i<vals.length;i++)
            vals[i] = rnd.nextInt(hmm.size());
        int maxInd=-1;
        double maxFit = 0;
        for (int i=0;i<vals.length;i++)
        {
            if (hmm.get(i).getFitness()>maxFit)
            {
                maxFit = hmm.get(i).getFitness();
                maxInd = i;
            }
        }
        
        return vals[maxInd];
    }

    public static Instances[] crossOver(Instances ds1, Instances ds2, boolean fixedSize) {
        Random rnd = new Random(System.currentTimeMillis());
        int ss= ds1.numInstances();
        int point1, point2;
        
        
        if (fixedSize)
        {
            point1 = DPLIB.rnd.nextInt(ss);
            point2 = point1;
        }
        else
        {        
            point1 = DPLIB.rnd.nextInt(ss);
            point2 = DPLIB.rnd.nextInt(ds2.numInstances());       
        
            if (ds1.numInstances()>4000)
            {            
                point1 = ds1.numInstances()/2;        
            }

            if (ds2.numInstances()>4000)
            {            
                point2 = ds2.numInstances()/2;        
            }
        }
        
        
        
        ds1.randomize(new Random(System.currentTimeMillis()));
        ds2.randomize(new Random(System.currentTimeMillis()));
        Instances ds1c = new Instances(ds1, 0);
        Instances ds2c = new Instances(ds2, 0);
        
        
        
        
        for (int i = 0; i < point1; i++) {
            ds1c.add(ds1.instance(i));
            
        }

        for (int i = 0; i < point2; i++) {
            ds2c.add(ds2.instance(i));
            
        }
        
        for (int i = point1; i < ds1.numInstances(); i++) {
            
            ds2c.add(ds1.instance(i));
        }
        
        
        for (int i = point2; i < ds2.numInstances(); i++) {
            ds1c.add(ds2.instance(i));
            
        }
        
        
        HashSet<Integer> pSet = new HashSet<Integer>();
        
        for (int i=0;i< ds1c.numInstances();i++)
        {
            if (pSet.contains(i))
                continue;
            HashSet<Integer> tmp = DPLIB.FindAllSimilarInstancesIndexes(i, ds1c);
            double lbl = 0;
            Integer[] t = tmp.toArray(new Integer[0]);
            int index=-1;
            for(int j=0;j<t.length;j++)
            {
                
                index = t[j];
                lbl+=ds1c.instance(index).classValue();
                pSet.add(index);
            }
            
            
            lbl = lbl/(t.length);
            if (lbl>=0.5)
                lbl=1;
            else
                lbl=0;
            
            
            
            for(int j=0;j<t.length;j++)
            {
                
                index = t[j];
                if ((int)ds1c.instance(index).classValue()!=(int)lbl)
                    ds1c.instance(index).SetExtra(ds1c.instance(index).GetExtra() +"-C="+String.valueOf((int)(1-lbl))+">"+String.valueOf((int)lbl));
                ds1c.instance(index).setClassValue(lbl);
            }
        }
        
        pSet.clear();
        for (int i=0;i< ds2c.numInstances();i++)
        {
            if (pSet.contains(i))
                continue;
            HashSet<Integer> tmp = DPLIB.FindAllSimilarInstancesIndexes(i, ds2c);
            double lbl = 0;
            Integer[] t = tmp.toArray(new Integer[0]);
            int index;
            for(int j=0;j<t.length;j++)
            {
                
                index = t[j];
                lbl+=ds2c.instance(index).classValue();
                pSet.add(index);
            }
            
            lbl = lbl/(t.length);
            if (lbl>=0.5)
                lbl=1;
            else
                lbl=0;
                        
            for(int j=0;j<t.length;j++)
            {
                
                index = t[j];
                
                if ((int)ds2c.instance(index).classValue()!=(int)lbl)
                    ds2c.instance(index).SetExtra(ds2c.instance(index).GetExtra() +"-C="+String.valueOf((int)(1-lbl))+">"+String.valueOf((int)lbl));
                
                ds2c.instance(index).setClassValue(lbl);
            }
        }
        
        return new Instances[]{ds1c, ds2c};
    }
    
}
