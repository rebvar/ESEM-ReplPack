/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wdp2;

import GIS.GIS;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import weka.core.Instances;

/**
 *
 * @author sehossei
 */
class myRunner implements Runnable {

    int iters;
    int folds;
    GIS gis;
    LSH.LSHCreateBinary lshbin;
    Instances trainSetAll;
    Instances testSetAll;
    
    private String file;
    String[] files;
    public int vSetCount = 20;
    public int vSetMaxDSSize = 250;
    String lrnrnames[] = new String[]{"nb","j48","bn", "dt", "log"};
    String savePath="";
    public myRunner(int iters, int folds, ArrayList<String> train, ArrayList<String> test, String file, String[] files, String savePath) throws Exception {

        this.file = file;
        this.iters = iters;
        this.folds = folds;        
        gis = new GIS();
        lshbin = new LSH.LSHCreateBinary();
        lshbin.file = file;
        gis.file = file;
        gis.iters = iters;
        this.files = files;
        this.savePath = savePath;
        trainSetAll = DPLIB.LoadCSV(train, DPLIB.dp, DPLIB.featuresa);
        testSetAll = DPLIB.LoadCSV((ArrayList) test, DPLIB.dp, DPLIB.featuresa);

    }

    public void doGIS(Instances trainSet, Instances testSet, String name, String lrnr, FileWriter fout, ArrayList<Instances> vSets, int vSetType, boolean fixedTrainSize, boolean log, String clfName) throws Exception {
        int c2 = 0;
        boolean ignoreCheck = false;

        Double thresholdDef = 0.1;
        Double threshold = thresholdDef;
        ArrayList<Double> thresholds = new ArrayList<>();
        thresholds.add(threshold);

        int forceAccepts = 0;
        boolean done = false;

        ArrayList<Double[]> rejectedPerfs = new ArrayList<>();
        ArrayList<Double[]> rejectedTestPerfs = new ArrayList<>();
        ArrayList<Double> rejectedFits = new ArrayList<>();

        while (true) {

            if (gis.GIS(trainSet, testSet, name + lrnr, fout, vSets, vSetType, fixedTrainSize, log, ignoreCheck, threshold, thresholds, rejectedFits, rejectedPerfs, rejectedTestPerfs, clfName)) {
                c2 = 0;

                ignoreCheck = false;

                threshold = thresholdDef;
                thresholds.clear();
                thresholds.add(threshold);

                rejectedPerfs.clear();
                rejectedTestPerfs.clear();
                rejectedFits.clear();

                break;
            } else {
                c2 += 1;
                if (c2 >= 3) {

                    c2 = 0;
                    ignoreCheck = true;
                    forceAccepts += 1;
                    System.out.println("#Too much Tries, force accepts (best):" + forceAccepts);
                    fout.write("#Too much Tries, force accepts (best):" + forceAccepts);
                    fout.write("\n");

                    double bestFit = Collections.max(rejectedFits);

                    int bestFitIndex = rejectedFits.indexOf(bestFit);

                    Double[] bestTestFit = rejectedTestPerfs.get(bestFitIndex);

                    System.out.print("*");
                    System.out.print(name + lrnr + ":" + file + ": ");
                    System.out.println(Arrays.toString(bestTestFit));

                    fout.write("*");
                    fout.write(name + lrnr + ":" + file + ": ");
                    fout.write(Arrays.toString(bestTestFit));
                    fout.write("\n");

                    fout.flush();

                    ignoreCheck = false;

                    threshold = thresholdDef;
                    thresholds.clear();
                    thresholds.add(threshold);

                    rejectedPerfs.clear();
                    rejectedTestPerfs.clear();
                    rejectedFits.clear();

                    break;
                } else {
                    continue;
                }
            }
        }

    }

    @Override
    public void run() {
        FileWriter fout = null;

        try {

            
            fout = new FileWriter(savePath+"NEW-GIS-" + String.valueOf(System.currentTimeMillis()) + " -- File=[" + file + "].txt");

            for (int lk = 0; lk < lrnrnames.length; lk++) {

                String lrnr = "";

                lrnr = "-" + lrnrnames[lk];

                String clfName = lrnrnames[lk];

                int c = 0;
                lshbin.fout = fout;

            
                ArrayList<Instances> vSets = new ArrayList<>();
            
                for (int i = 0; i < vSetCount; i++) {

                    Random rnd = DPLIB.rnd;
                    Instances vSet = new Instances(trainSetAll, 0);
    
                    int size = (int) (vSetMaxDSSize / 2) + DPLIB.rnd.nextInt(vSetMaxDSSize / 2);
                    trainSetAll.randomize(rnd);    

                    int j = 0;
                    int gcnt = (int) rnd.nextInt(vSetMaxDSSize - 5) + 5;
                    int sizes[] = {gcnt, size - gcnt};
                    for (int k = 0; k < 2; k++) {
                        int cntclass = 0;

                        while (cntclass < sizes[k]) {
                            //int ind = DPLIB.rnd.nextInt(trainSetAll.numInstances());
                            if (k == 0 && (int) trainSetAll.instance(j).classValue() == k) {
                                vSet.add(trainSetAll.instance(j));
                                cntclass++;
                            } else if (k != 0 && (int) trainSetAll.instance(j).classValue() > 0) {
                                vSet.add(trainSetAll.instance(j));
                                cntclass++;
                            }
                            j++;
                        }
                    }
                    vSets.add(vSet);
                }

                while (c < iters) {

                    System.out.println("Start:" + file + ": " + String.valueOf(c));
                    System.out.println("====================================================");
                    fout.write("#ITERINFO:For File=" + file + "-Iter:" + String.valueOf(c) + "\n");

                    String sbtx;                    
                    sbtx = "-TUNE-v"+String.valueOf(vSetCount)+"-vmx"+String.valueOf(vSetMaxDSSize)+"-";
                    
                    lshbin.CreateBucketsTune(trainSetAll, testSetAll, vSets, "LSHTune-ALL-TOP-SUPER" + sbtx + lrnr, false, c, false, true, clfName,false);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                    
                    sbtx = "-CLFTU-TUNE-v"+String.valueOf(vSetCount)+"-vmx"+String.valueOf(vSetMaxDSSize)+"-";                    
                    lshbin.CreateBucketsTune(trainSetAll, testSetAll, vSets, "LSHTune-ALL-TOP-SUPER" + sbtx + lrnr, false, c, false, true, clfName,true);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                    
                    
                    doGIS(trainSetAll, testSetAll, "FIXED-VMUL-GEN-A", lrnr, fout, vSets, 0, true, false, clfName);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                    
                    doGIS(trainSetAll, testSetAll, "FIXED-VNN-GEN-A", lrnr, fout, null, 1, true, false, clfName);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                                       
                    
                    doGIS(trainSetAll, testSetAll, "VAR-VMUL-GEN-A", lrnr, fout, vSets, 0, false, false, clfName);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                                          
                    doGIS(trainSetAll, testSetAll, "VAR-VNN-GEN-A", lrnr, fout, null, 1, false, false, clfName);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                    
                    
                    Benchmarks.NNFilter(trainSetAll, testSetAll, file, fout, "TuneNNFILTER-A-0" + lrnr, null, 0, clfName,false,vSets,false);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                    
                    Benchmarks.NNFilter(trainSetAll, testSetAll, file, fout, "TunedNNFILTER-A-0-TUNEDCLF" + lrnr, null, 0, clfName,true,vSets,false);
                    System.out.println("------------------");
                    fout.write("------------------\n");
                                        
                    fout.write("----------------------------------------------\n");
                    fout.flush();
                    System.gc();
                    System.out.println("Finished:" + file + ": " + String.valueOf(c));
                    c++;
                }
            }
            fout.write("===================================================================\n");
            fout.close();

            System.out.println("File Processing Ended:" + file);
        } catch (Exception e) {

            try {
                fout.write("#ERROR:"+e.toString()+";;;TRACE:" + Arrays.toString(e.getStackTrace())+"\n\n\n");
                fout.flush();
                fout.close();
            } catch (Exception ex2) {
                System.out.println(ex2.getMessage());
            }

            e.printStackTrace();

        }

    }

}

public class BC {

    public static int iters = 20;

    public static void RunTests(String savePath, int procCount)
            throws Exception {

        
        DPLIB.convertToBinary = true;
        int folds = 10;
        String Path="";
        
        Path = savePath;
        
        java.io.File PathFolder = new File(Path);
        if (!PathFolder.exists()) {
            PathFolder.mkdirs();
        }

        ExecutorService procs = Executors.newFixedThreadPool(procCount);

        String startTST = "";
        String endTST = "";
        String[] files = DPLIB.getFiles(DPLIB.dp);
        for (String file : files) {
            if (endTST.length() > 0 && file.compareTo(endTST) >= 0) {
                break;
            }
            if (file.compareTo(startTST) >= 0) {
                ArrayList<String> train = new ArrayList<String>();
                for (String file2 : files) {
                    if (!file2.substring(0, 3).equals(file.substring(0, 3))) {
                        train.add(file2);
                    }
                }

                ArrayList<String> test = new ArrayList<String>();
                test.add(file);

                procs.submit(new myRunner(iters, folds, train, test, file, files,savePath));
            }
        }

        procs.shutdown();

        try {
            procs.awaitTermination(100, TimeUnit.DAYS);
        } catch (InterruptedException e) {        
            e.printStackTrace();
        }

    }
}
