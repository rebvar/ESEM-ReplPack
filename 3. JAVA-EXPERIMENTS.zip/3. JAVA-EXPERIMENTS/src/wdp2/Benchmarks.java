/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wdp2;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;

import weka.classifiers.evaluation.Prediction;

import weka.core.Instances;

/**
 *
 * @author sehossei
 */
public class Benchmarks {
        
    public static ArrayList<Prediction> NNFilter (Instances trainSeti, Instances testSeti, String file, FileWriter fout, String name, ArrayList<Prediction> vecin, int count, String clfName, boolean tunelrn, ArrayList<Instances> vSets, boolean testCut) throws Exception
    {
        
        double spentISTime = 0;
        double tempTime = 0;
        Instances testSet = new Instances (testSeti);
        double bestFit = 0.0;
        int bestCount = 0;
        Instances btrainSet = null;
        double cfbf = DPLIB.cf;
          
        if (count == 0){
            for (int  i = 1;i<=10;i++)
            {
                tempTime = System.currentTimeMillis();
                  
                Instances trainSet = DPLIB.NNFilter(trainSeti, testSet, i);

                spentISTime+=System.currentTimeMillis()-tempTime;
                  
                GLOB g = new GLOB(clfName, tunelrn);
                Classifier l;
                if (tunelrn)
                {
                    l = g.getTunedCLF(trainSet, vSets,fout,name, file);                        
                }
                else
                    l = g.getClassifier();
                  
                l.buildClassifier(trainSet);
                  
                  
                double avgFit  = 0.0;
                int j = 0;
                for (j = 0;j<vSets.size();j++)
                {
                    Evaluation eval = new Evaluation(trainSet);
                    eval.evaluateModel(l, vSets.get(j), new Object[0]);
                    ArrayList<Prediction> vec = eval.predictions();

                
                    double tvals[] = DPLIB.getResults(vec);
                    HashMap<String, Double> measures = DPLIB.getExtMeasures(tvals);
                    double fit = measures.get("F")*measures.get("GMean1");
                    avgFit += fit;

                }
                  
                avgFit/=vSets.size();
                  
                  
                if (avgFit>bestFit){
                    bestFit = avgFit;
                    bestCount = i;
                    btrainSet = new Instances(trainSet);
                }                  
                  
            }
                                        
        }
          
        Instances trainSet;
        if (count == 0)
            trainSet = btrainSet;
        else
        {
              
            tempTime = System.currentTimeMillis();
            trainSet = DPLIB.NNFilter(trainSeti, testSet, count);
            spentISTime = System.currentTimeMillis() - tempTime;
            bestCount = count;
        }

        GLOB g = new GLOB(clfName, tunelrn);
        Classifier l;
        if (tunelrn)
        {
            l = g.getTunedCLF(trainSet, vSets,fout,name, file);

            System.out.print("#TUNE-LRN-PARAMS-"+name+":" + file + ": ");                
            System.out.println(Arrays.toString(g.selectedParams));                
            fout.write("#TUNE-LRN-PARAMS-"+name+":" + file + ": ");
            fout.write(Arrays.toString(g.selectedParams));fout.write("\n");                
            String sCheck[]= g.getCLFOptions();                

            System.out.print("#SETSET-LRN-PARAMS-"+name+":" + file + ": ");                
            System.out.println(Arrays.toString(sCheck));                                
            fout.write("#SETSET-LRN-PARAMS-"+name+":" + file + ": ");                
            fout.write(Arrays.toString(sCheck));fout.write("\n");


        }
        else 
            l = g.getClassifier();
        l.buildClassifier(trainSet);

                  
        Evaluation eval = new Evaluation(trainSet);
        eval.evaluateModel(l, testSet, new Object[0]);
        ArrayList<Prediction> vec = eval.predictions();
        vecin = vec;
          
        double vals[] = DPLIB.getResults(vecin,cfbf);
        if (count == 0)
        {
            System.out.print("#BESTCOUNT-"+name+":" + file + ": ");
            System.out.println(bestCount);
          
            fout.write("#BESTCOUNT-"+name+":" + file + ": ");
            fout.write(String.valueOf(bestCount));fout.write("\n");
          
            System.out.print("#BESTFIT-"+name+":" + file + ": ");
            System.out.println(bestFit);
          
            fout.write("#BESTFIT-"+name+":" + file + ": ");
            fout.write(String.valueOf(bestFit));fout.write("\n");
          
        }
          
        System.out.print("#CONF-TEST-"+name+":" + file + ": ");
        System.out.println(Arrays.toString(vals));
          
        fout.write("#CONF-TEST-"+name+":" + file + ": ");
        fout.write(Arrays.toString(vals));fout.write("\n");
        
        vals = DPLIB.getMeasures(vals);                  
        System.out.print(name+":" + file + ": ");
        System.out.println(Arrays.toString(vals));
        
          
          
        fout.write(name+":" + file + ": ");
        fout.write(Arrays.toString(vals));
        fout.write("\n");
        
                            
        System.out.println("#TIME-FOR-IS:"+name+":" + file + ": "+spentISTime);
        fout.write("#TIME-FOR-IS:"+name+":" + file + ": "+String.valueOf(spentISTime)+"\n");
                  
        return vecin;
    }        
    
}
