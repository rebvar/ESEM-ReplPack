package wdp2;

public class WekaDP
{
    
    public static void RunGISLSHNNFamulti (String savePath,String dp, int procCount) throws  Exception
    {
      DPLIB.features = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
      DPLIB.featuresa = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
      DPLIB.dp = dp;
      
      if (procCount<=0)
          procCount=1;
      BC.RunTests(savePath, procCount);
        
    }
    
  public static void main(String[] args)
    throws Exception
  {
      
      String dp= "D:/DataPacks/D5/";
      int procCount = 1;
      String savePath = "D:/GISOUT/EXPLORE/";
      if (args.length>0)
      {
          for (int i = 0;i< args.length;i++)
          {
              if (args[i].equals("-dp"))
              {
                  dp = args[i+1];
              }
              
              if (args[i].equals("-pc"))
              {
                  procCount = Integer.parseInt(args[i+1]);
              }
              
              if (args[i].equals("-sp"))
              {
                  savePath = args[i+1];
              }
          }
      }
      
      System.out.println("DP:"+dp);
      System.out.println("SP:"+savePath);
      System.out.println("PCount:"+procCount);

      RunGISLSHNNFamulti(savePath,dp,procCount);      
      
  }
}
