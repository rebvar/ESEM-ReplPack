package wdp2;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.evaluation.Prediction;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.functions.SMO;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.trees.J48;
import weka.core.Instances;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author sehossei
 */
public class GLOB {

    public static double ep = 0.000000001;
    String lrnrs[] = {"log", "dt", "j48", "bn", "nb"};
    HashMap<String, HashMap<String, ArrayList<String>>> options = new HashMap<>();
    ArrayList<String> tf;
    boolean optimize;
    int curOpt = 0;
    Classifier clf = null;
    String[] keys;
    int Counts[];
    int curCounts[];
    boolean end = false;
    String defOptions[];
    
    public String selectedParams[];
    
    
    public ArrayList getRangeStr(double start, double end, double step) {
        ArrayList<String> ret = new ArrayList<>();

        while (start <= end) {
            ret.add(String.format("%f", start));
            start += step;
        }

        return ret;
    }

    public ArrayList getRangeStr(int start, int end, int step) {
        ArrayList<String> ret = new ArrayList<>();

        while (start <= end) {
            ret.add(String.format("%d", start));
            start += step;
        }

        return ret;
    }
    
    public ArrayList getRandomRangeStr(int start, int end, int count) {
        
        HashSet<Integer> vals = new HashSet<>();
        ArrayList<String> ret = new ArrayList<>();
        Random r=new Random();
        while (vals.size()<count)
        {
            
            int rnd = r.nextInt(end-start)+start;
            if (vals.contains(rnd))
                continue;
            vals.add(rnd);
            ret.add(String.valueOf(rnd));            
        }
        return ret;
    }
    
    public ArrayList getRandomRangeStr(double start, double end, int count) {
        
        HashSet<Double> vals = new HashSet<>();
        ArrayList<String> ret = new ArrayList<>();
        Random r=new Random();
        while (vals.size()<count)
        {
            
            double rnd = r.nextDouble()*(end-start)+start;
            if (vals.contains(rnd))
                continue;
            vals.add(rnd);
            ret.add(String.valueOf(rnd));            
        }
        return ret;
    }
    
    
    public void buildOptionsMap() throws Exception {

        tf = new ArrayList<>();
        tf.add("true");
        tf.add("false");

        HashMap<String, ArrayList<String>> jopts = new HashMap<>();
        if ("j48".equals(clfName)) {
            jopts.put("M", getRangeStr(1, 64, 10));
            jopts.put("C", getRangeStr(0.1, 0.5, 0.1));
            options.put(clfName, jopts);
        } else if ("dt".equals(clfName)) {

            ArrayList<String> measures = new ArrayList<>();
            measures.add("acc");
            measures.add("rmse");
            measures.add("mae");    
            jopts.put("E", measures);
            jopts.put("I", tf);
            ArrayList<String> sm = new ArrayList<>();
            sm.add("weka.attributeSelection.BestFirst -D 0");
            sm.add("weka.attributeSelection.BestFirst -D 1");
            sm.add("weka.attributeSelection.BestFirst -D 2");
            sm.add("weka.attributeSelection.GreedyStepwise");
            jopts.put("S", sm);
            jopts.put("X", getRangeStr(1, 1, 1));
            options.put(clfName, jopts);
        } else if ("bn".equals(clfName)) {

            ArrayList<String> q = new ArrayList<>();
            q.add("weka.classifiers.bayes.net.search.local.K2");            
            q.add("weka.classifiers.bayes.net.search.global.TAN");
            jopts.put("Q", q);
            jopts.put("D", tf);

            options.put(clfName, jopts);
        } else if ("nb".endsWith(clfName)) {
            jopts.put("K", tf);
            jopts.put("D", tf);
            options.put(clfName, jopts);
        } else if ("log".endsWith(clfName)) {

            jopts.put("R", getRandomRangeStr(0.01, 10.0, 20));
            options.put(clfName, jopts);
        } else {
            throw new Exception("Not Implemented for " + clfName);
        }

        keys = options.get(clfName).keySet().toArray(new String[0]);
        Arrays.sort(keys);

        Counts = new int[keys.length];
        curCounts = new int[keys.length];
        for (int i = 0; i < Counts.length; i++) {
            Counts[i] = options.get(clfName).get(keys[i]).size();
            curCounts[i] = 0;
        }
    }

    public String clfName;

    public GLOB() throws Exception {

        clfName = "nb";
        clf = getClassifierByName();
        if (optimize) {
            buildOptionsMap();
        }

    }

    public Classifier getTunedCLF(Instances trSet, ArrayList<Instances> vSets, FileWriter fout, String name, String file) throws Exception {
        String[] bestOpts = null;
        double bestFit = -1;
        double[] bestVals = null;
        double vCF = 0.5;
        if (vSets == null) {
            vSets = new ArrayList<>();
        }
        
        if (vSets.size() == 0) {
            vSets.add(trSet);
        }
        int count;
        int iter = 0;
        
        while (!end) {
            double afit = 0;
            String[] cOpts = getNextOptions();
                        
            Classifier l = getClassifierWithOptions(cOpts);

            l.buildClassifier(trSet);

            int j = 0;

            for (Instances vSet : vSets) {
                Evaluation evaluation = new Evaluation(trSet);
                if (vSet != null) {
                    evaluation.evaluateModel(l, vSet, new Object[0]);
                } else {
                    evaluation.evaluateModel(l, trSet, new Object[0]);
                }

                ArrayList<Prediction> vec = evaluation.predictions();

                double[] tvals = DPLIB.getResults(vec, vCF);
                HashMap<String, Double> measures = DPLIB.getExtMeasures(tvals);
                double fit = measures.get("F") * measures.get("GMean1");
                afit += fit;
            }
            afit /= vSets.size();

            if (afit > bestFit) {
                bestFit = afit;
                
                bestOpts = cOpts.clone();
            }
            iter+=1;
        
        }
        
        selectedParams = bestOpts.clone();
        //System.out.println("##SELECTED TUNE PARAMS:FOR: "+name+" ;; FILE="+ file +" PARAMS: " + Arrays.toString(selectedParams)+"   Best FIT:"+String.valueOf(bestFit));
        //fout.write("##SELECTED TUNE PARAMS:FOR: "+name+" ;; FILE="+ file +" PARAMS: " + Arrays.toString(selectedParams)+"   Best FIT:"+String.valueOf(bestFit)+"\n");
        return getClassifierWithOptions(bestOpts);
                     
    }

    public Classifier getTunedCLFCV(Instances trSet, int folds) throws Exception {
        String[] bestOpts = null;
        double bestFit = -1;
        double[] bestVals = null;
        double vCF = 0.5;
        double vals[] = null;
        while (!end) {        
            String[] cOpts = getNextOptions();
                        
            Classifier l = getClassifierWithOptions(cOpts);

            trSet.stratify(folds);
            for (int j = 0; j < folds; j++) {
                Instances cvtrain = new Instances(trSet.trainCV(folds, j));
                Instances cvtest = new Instances(trSet.testCV(folds, j));

                l.buildClassifier(cvtrain);
                Evaluation evaluation = new Evaluation(cvtrain);
                evaluation.evaluateModel(l, cvtest, new Object[0]);
                ArrayList<Prediction> vec = evaluation.predictions();
                //preds.add(vec);
                if (vals == null) {
                    vals = DPLIB.getResults(vec);
                } else {
                    double[] v2 = DPLIB.getResults(vec);
                    for (int k = 0; k < v2.length; k++) {
                        vals[k] += v2[k];
                    }
                }
            }
            
            HashMap<String, Double> measures = DPLIB.getExtMeasures(vals);
            double fit = measures.get("F") * measures.get("GMean1");
            if (fit>bestFit)
            {
                bestFit = fit;
                bestOpts = cOpts.clone();
            }
        }
        selectedParams = bestOpts.clone();
        return getClassifierWithOptions(bestOpts);
    }

    public GLOB(String name) throws Exception {
        clfName = name;
        clf = getClassifierByName();
        if (optimize) {
            buildOptionsMap();
        }
    }

    public GLOB(String name, boolean opt) throws Exception {
        clfName = name;

        optimize = opt;
        clf = getClassifierByName();
        if (optimize) {
            buildOptionsMap();
        }

    }

    public Classifier getClassifier() {
        return clf;
    }

    public Classifier getClassifierNextOptions1() {

        if (!end) {
            
            String cOpts[] = getNextOptions();
            
            return getClassifierWithOptions(cOpts);
        }
        return null;
    }

    public Classifier getClassifierWithOptions(String[] nxOpts1) {
        String nxOpts[] = nxOpts1.clone();
        try {
            if ("log".equals(clfName)) {
                ((Logistic) clf).setOptions(nxOpts);
                return clf;

            } else if ("dt".equals(clfName)) {
                ((DecisionTable) clf).setOptions(nxOpts);
                return clf;

            } else if ("j48".equals(clfName)) {
                ((J48) clf).setOptions(nxOpts);
                return clf;
            } else if ("svm".equals(clfName)) {
                ((SMO) clf).setOptions(nxOpts);
                return clf;
            } else if ("mlp".equals(clfName)) {
                ((MultilayerPerceptron) clf).setOptions(nxOpts);
                return clf;
            } else if ("bn".equals(clfName)) {
                ((BayesNet) clf).setOptions(nxOpts);
                return clf;
            } 
            else 
            {
                ((NaiveBayes) clf).setOptions(nxOpts);
                return clf;
            }
        } catch (Exception ee) {            
            return clf;
        }
    }
    
    
    public String[] getCLFOptions() {        
        try {
            if ("log".equals(clfName)) {
                return ((Logistic) clf).getOptions(); 
            } else if ("dt".equals(clfName)) {
                return ((DecisionTable) clf).getOptions();                 
            } else if ("j48".equals(clfName)) {
                return ((J48) clf).getOptions();                 
            } else if ("svm".equals(clfName)) {
                return ((SMO) clf).getOptions();                 
            } else if ("mlp".equals(clfName)) {
                return ((MultilayerPerceptron) clf).getOptions(); 
            } else if ("bn".equals(clfName)) {
                return ((BayesNet) clf).getOptions();                 
            } else
            {
                return  ((NaiveBayes) clf).getOptions();                 
            }
        } catch (Exception ee) {            
            return new String[0];
        }
    }

    public String[] getNextOptions() {

        if (!optimize) {
            end = true;
            return defOptions;
        }
        if (end) {
            return new String[]{"!!END!!"};
        }

        curOpt += 1;

        int i = 0;

        boolean same = true;

        for (i = 0; i < Counts.length; i++) {
            if (Counts[i] != curCounts[i] + 1) {
                same = false;
                break;
            }
        }

        ArrayList<String> ov = new ArrayList<>();
        for (i = 0; i < keys.length; i++) {
            String optVal = options.get(clfName).get(keys[i]).get(curCounts[i]);
            if ("true".equals(optVal)) {
                ov.add("-" + keys[i]);
            } else if ("false".equals(optVal)) {
                continue;
            } else {
                ov.add("-" + keys[i]);
                ov.add(optVal);
            }
        }

        if (same) {
            end = true;
        } else {
            i = 0;
            curCounts[0] += 1;
            while (i < Counts.length - 1) {
                if (curCounts[i] >= Counts[i]) {
                    curCounts[i] = 0;
                    curCounts[i + 1] += 1;
                } else {
                    break;
                }
                i += 1;
            }
        }

        return ov.toArray(new String[0]);
    }

    public ArrayList<String[]> getAllOptions() {
        ArrayList<String[]> allopts = new ArrayList<String[]>();

        while (!end) {
            String[] nxopt = getNextOptions();

            if (!"!!END!!".equals(nxopt[0])) {
                allopts.add(nxopt);
            } else {
                break;
            }
        }

        return allopts;
    }

    public Classifier getClassifierByName() {

        switch (clfName) {
            case "log": {
                Logistic log = new Logistic();
                defOptions = log.getOptions();
                return log;
            }
            case "dt": {
                DecisionTable dt = new DecisionTable();
                defOptions = dt.getOptions();
                return dt;

            }
            case "j48": {
                J48 j48 = new J48();
                defOptions = j48.getOptions();
                return j48;
            }
            case "svm": {
                SMO smo = new SMO();
                defOptions = smo.getOptions();
                return smo;
            }
            case "mlp": {
                MultilayerPerceptron mlp = new MultilayerPerceptron();
                defOptions = mlp.getOptions();
                return mlp;
            }
            case "bn": {
                BayesNet bn = new BayesNet();
                defOptions = bn.getOptions();
                return bn;
            }
            case "nb":
            default: {
                NaiveBayes nb = new NaiveBayes();
                defOptions = nb.getOptions();
                return nb;
            }
        }
    }

    public Classifier getRegressor() {
        return new LinearRegression();
    }
}
